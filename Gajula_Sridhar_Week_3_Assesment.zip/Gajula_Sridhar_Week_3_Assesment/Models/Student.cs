﻿namespace Gajula_Sridhar_Week_3_Assesment.Models
{
    public class Student
    {
        public int StudentId { get; set; }  
        public string StudentName { get; set; }

        public string Qualification { get; set; }

        public string Skill { get; set; }
    }
}
