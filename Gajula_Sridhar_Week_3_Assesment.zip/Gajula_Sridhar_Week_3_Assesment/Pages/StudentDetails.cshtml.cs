using Gajula_Sridhar_Week_3_Assesment.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using static System.Reflection.Metadata.BlobBuilder;

namespace Gajula_Sridhar_Week_3_Assesment.Pages
{
    public class StudentDetailsModel : PageModel
    {
        static List<Student> student = new List<Student>()
         {
            new Student(){ StudentId=1,StudentName="Sridhar",Qualification="Btech",Skill="Dot net Full-stack"},
              new Student(){ StudentId=2,StudentName="Sai",Qualification="Btech",Skill="Java Full-stack"}
         };
        [BindProperty]
        public Student Student { get; set; }
        public List<Student> Students { get { return student; } }
        public void OnGet()
        {
        }
        public IActionResult OnPost()
        {
            student.Add(Student);
            return (RedirectToPage("StudentDetails"));
        }
    }
}
